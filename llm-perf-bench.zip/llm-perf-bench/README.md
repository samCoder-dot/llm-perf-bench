# LLM Performance Benchmark Suite

Reproducible measurement of **processing speed, memory usage and GPU utilisation** for large language
models (Gemma 12B / ~30B class or comparable) served through any OpenAI-compatible endpoint
(the contest application, Ollama, llama.cpp `llama-server`, vLLM, LM Studio).

> `examples/` holds a **synthetic dry run against a mock server**, to show output formats only.
> It contains no real GPU numbers. Real results go in `results/` and `report/`.

## What is measured

| Area | Metric | How |
|---|---|---|
| Speed | Time-to-first-token (p50/p95) | first streamed content chunk, `perf_counter` |
| Speed | Decode tokens/s per stream | `(completion_tokens-1) / (t_end - t_first_token)` |
| Speed | Aggregate tokens/s | tokens of a concurrent round / round wall time |
| Speed | End-to-end latency (p50/p95) | request start to stream end |
| GPU | Utilisation %, memory-controller %, power W, temp, SM clock | NVML at 2 Hz (nvidia-smi fallback) |
| Memory | VRAM idle (model loaded) vs peak, server-process RAM, system RAM | NVML + psutil |

Sweep: prompt length {128, 512, 2048} x concurrency {1, 2, 4, 8} x 5 rounds (all configurable).
Each request carries a unique nonce to defeat prompt caching; temperature 0; fixed seed; token counts come
from the server's `usage` field (chunk count as fallback).

## Quick start

```bash
git clone <this repo> && cd llm-perf-bench
bash scripts/runpod_setup.sh gemma3:12b          # RunPod / fresh Ubuntu (locally: install Ollama + pip install -r requirements.txt)
bash scripts/run_all.sh "gemma3:12b=gemma-12b"   # runs the sweep and builds report/
```

Against the contest application (any OpenAI-compatible URL):

```bash
python bench/run_benchmark.py --base-url http://localhost:8080/v1 --model <name> --label myrun
python bench/report.py results/myrun
```

Compare models or GPUs by passing several `results/<label>` folders to `report.py`.

## Hardware guidance

| Model class (4-bit quant) | Approx. VRAM | Suitable GPU |
|---|---|---|
| ~12B | 8-10 GB | RTX 3060 12 GB and up |
| ~27-31B | 17-22 GB | 24 GB cards (RTX 3090/4090, A5000, L4) |

Use RunPod for the larger model if your local GPU has 12 GB. CPU offload (model not fully in VRAM) skews every
metric; the report shows VRAM peak vs total so offload is visible.

## Output layout

```
results/<label>/  requests.csv|json  rounds.csv  telemetry.csv  phases.csv  env.json   <- raw logs
report/           results.md  summary.csv  summary.json  *.png                         <- deliverables
```

## Reproducibility
- `env.json` captures GPU, driver, CPU, RAM, model, seed and start time.
- Close other GPU consumers; note any clock/power-limit changes via `--note`.
- Same `--seed` on re-runs; compare `aggregate_tps_std` for run-to-run variance.
- Client-supplied scripts can live in `bench/` and reuse `monitor.GpuMonitor`.

## Key takeaways
*(filled in after the real run; see `report/results.md`)*
