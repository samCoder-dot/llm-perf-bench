#!/usr/bin/env python3
"""Fake OpenAI-compatible streaming server so you can dry-run the harness without a GPU."""
import json, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

active = 0
lock = threading.Lock()


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def do_POST(self):
        global active
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        n_prompt = len(body["messages"][0]["content"].split())
        n_out = min(body.get("max_tokens", 64), 96)
        with lock:
            active += 1
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream"); self.end_headers()
            time.sleep(0.05 + n_prompt / 4000)                      # fake prefill
            for i in range(n_out):
                time.sleep(0.008 * (1 + 0.35 * (active - 1)))        # fake decode, slows with load
                c = {"choices": [{"delta": {"content": f"w{i} "}}]}
                self.wfile.write(f"data: {json.dumps(c)}\n\n".encode()); self.wfile.flush()
            u = {"choices": [], "usage": {"prompt_tokens": int(n_prompt * 1.35), "completion_tokens": n_out}}
            self.wfile.write(f"data: {json.dumps(u)}\n\ndata: [DONE]\n\n".encode()); self.wfile.flush()
        finally:
            with lock:
                active -= 1


if __name__ == "__main__":
    print("mock server on :8000/v1")
    ThreadingHTTPServer(("127.0.0.1", 8000), H).serve_forever()
