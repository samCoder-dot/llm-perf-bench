#!/usr/bin/env python3
"""Benchmark any OpenAI-compatible LLM endpoint (Ollama, llama.cpp, vLLM, LM Studio, the contest app...).

Measures per-request TTFT, decode tokens/s, end-to-end latency and aggregate throughput under
increasing concurrency, while a background thread logs GPU / CPU / RAM telemetry.
"""
import argparse, asyncio, csv, json, random, time
from pathlib import Path
import httpx
from monitor import GpuMonitor, collect_env

VOCAB = ("river engine signal garden market window protocol harvest compiler lantern orbit pattern "
         "bridge ledger thunder canvas mirror cipher meadow anchor beacon quartz fabric summit "
         "voltage harbor script mosaic kernel desert timber prism vector ember glacier relay "
         "orchard matrix pillar saddle tunnel velvet whistle zenith cobalt delta fiber granite").split()
REQ_FIELDS = ["label", "prompt_nominal", "concurrency", "round", "ok", "error", "prompt_tokens",
              "completion_tokens", "ttft_s", "decode_s", "decode_tps", "e2e_s", "e2e_tps", "start_epoch"]


def make_prompt(n_tokens, rng):
    words = " ".join(rng.choice(VOCAB) for _ in range(int(n_tokens / 1.35)))
    # unique nonce at the front defeats prefix caching, so every request pays a full prefill
    return (f"[req {rng.randrange(10**9)}] Read these notes and write a detailed, long-form "
            f"analysis of at least 300 words.\n\n{words}")


async def one_request(client, url, headers, model, prompt, max_tokens):
    payload = {"model": model, "messages": [{"role": "user", "content": prompt}], "max_tokens": max_tokens,
               "temperature": 0, "stream": True, "stream_options": {"include_usage": True}}
    start_epoch, t0, first, chunks, usage, err = time.time(), time.perf_counter(), None, 0, None, ""
    try:
        async with client.stream("POST", url, json=payload, headers=headers) as r:
            if r.status_code >= 400:
                raise RuntimeError(f"HTTP {r.status_code}: {(await r.aread())[:200]!r}")
            async for line in r.aiter_lines():
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                obj = json.loads(data)
                if obj.get("usage"):
                    usage = obj["usage"]
                for ch in obj.get("choices") or []:
                    d = ch.get("delta") or {}
                    if d.get("content") or d.get("reasoning_content"):
                        if first is None:
                            first = time.perf_counter()
                        chunks += 1
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
    t1 = time.perf_counter()
    ctoks = (usage or {}).get("completion_tokens") or chunks
    ok = not err and first is not None and ctoks > 0
    dec = (t1 - first) if first else None
    return {"ok": ok, "error": err, "prompt_tokens": (usage or {}).get("prompt_tokens"),
            "completion_tokens": ctoks, "ttft_s": round(first - t0, 4) if first else None,
            "decode_s": round(dec, 4) if dec else None,
            "decode_tps": round((ctoks - 1) / dec, 2) if ok and dec and ctoks > 1 else None,
            "e2e_s": round(t1 - t0, 4), "e2e_tps": round(ctoks / (t1 - t0), 2) if ok else None,
            "start_epoch": round(start_epoch, 3)}


def write_csv(path, rows, fields):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


async def main_async(a):
    out = Path(a.out) / a.label
    out.mkdir(parents=True, exist_ok=True)
    url = a.base_url.rstrip("/") + "/chat/completions"
    headers = {"Authorization": f"Bearer {a.api_key}"} if a.api_key else {}
    rng = random.Random(a.seed)
    env = collect_env()
    env.update(label=a.label, model=a.model, base_url=a.base_url, max_tokens=a.max_tokens, seed=a.seed,
               started=time.strftime("%Y-%m-%d %H:%M:%S"), note=a.note)
    mon = GpuMonitor(a.interval, a.gpu_index, a.server_proc.split(","), out / "telemetry.csv")
    mon.start()
    phases, reqs, rounds = [], [], []

    async with httpx.AsyncClient(timeout=httpx.Timeout(a.timeout, connect=10)) as client:
        t = time.time()
        await asyncio.sleep(a.idle)
        phases.append({"name": "idle", "start": t, "end": time.time()})

        t = time.time()
        for _ in range(a.warmup):
            await one_request(client, url, headers, a.model, make_prompt(64, rng), 32)
        phases.append({"name": "warmup", "start": t, "end": time.time()})

        for conc in a.concurrency:
            for size in a.prompt_sizes:
                t = time.time()
                for rd in range(a.rounds):
                    prompts = [make_prompt(size, rng) for _ in range(conc)]
                    w0 = time.perf_counter()
                    res = await asyncio.gather(*[one_request(client, url, headers, a.model, p, a.max_tokens)
                                                 for p in prompts])
                    wall = time.perf_counter() - w0
                    good = [r for r in res if r["ok"]]
                    toks = sum(r["completion_tokens"] for r in good)
                    for r in res:
                        r.update(label=a.label, prompt_nominal=size, concurrency=conc, round=rd)
                    reqs += res
                    rounds.append({"label": a.label, "prompt_nominal": size, "concurrency": conc,
                                   "round": rd, "wall_s": round(wall, 3), "completion_tokens": toks,
                                   "agg_tps": round(toks / wall, 2), "errors": len(res) - len(good)})
                    errs = {r["error"] for r in res if r["error"]}
                    print(f"[{a.label}] conc={conc} prompt~{size} round={rd}: "
                          f"{rounds[-1]['agg_tps']} tok/s aggregate, errors={len(res)-len(good)} {errs or ''}",
                          flush=True)
                phases.append({"name": "bench", "prompt_nominal": size, "concurrency": conc,
                               "start": t, "end": time.time()})
                await asyncio.sleep(a.cooldown)

    mon.stop()
    write_csv(out / "requests.csv", reqs, REQ_FIELDS)
    write_csv(out / "rounds.csv", rounds, ["label", "prompt_nominal", "concurrency", "round", "wall_s",
                                           "completion_tokens", "agg_tps", "errors"])
    write_csv(out / "phases.csv", phases, ["name", "prompt_nominal", "concurrency", "start", "end"])
    (out / "env.json").write_text(json.dumps(env, indent=2))
    (out / "requests.json").write_text(json.dumps(reqs, indent=1))
    print(f"Done. Raw results in {out}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--base-url", default="http://localhost:11434/v1", help="OpenAI-compatible base URL")
    p.add_argument("--model", required=True, help="model name as the server knows it, e.g. gemma3:12b")
    p.add_argument("--label", required=True, help="results folder name, e.g. gemma-12b-rtx3060")
    p.add_argument("--api-key", default="")
    p.add_argument("--prompt-sizes", type=int, nargs="+", default=[128, 512, 2048])
    p.add_argument("--concurrency", type=int, nargs="+", default=[1, 2, 4, 8])
    p.add_argument("--rounds", type=int, default=5)
    p.add_argument("--max-tokens", type=int, default=256)
    p.add_argument("--warmup", type=int, default=3)
    p.add_argument("--idle", type=float, default=5, help="seconds of idle baseline telemetry")
    p.add_argument("--cooldown", type=float, default=2)
    p.add_argument("--interval", type=float, default=0.5, help="telemetry sampling period (s)")
    p.add_argument("--gpu-index", type=int, default=0)
    p.add_argument("--server-proc", default="ollama,llama-server,vllm",
                   help="process-name substrings whose RSS is summed as 'server RAM'")
    p.add_argument("--timeout", type=float, default=600)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--note", default="")
    p.add_argument("--out", default="results")
    asyncio.run(main_async(p.parse_args()))


if __name__ == "__main__":
    main()
