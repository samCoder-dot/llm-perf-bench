"""System + GPU telemetry sampler (NVML first, nvidia-smi fallback)."""
import csv, platform, shutil, subprocess, sys, threading, time
import psutil

try:
    import pynvml
except Exception:  # pragma: no cover
    pynvml = None

FIELDS = ["t", "gpu_util", "mem_ctrl_util", "vram_used_mb", "vram_total_mb", "power_w",
          "temp_c", "sm_clock_mhz", "cpu_pct", "ram_used_mb", "server_rss_mb"]
GPU_KEYS = ["gpu_util", "mem_ctrl_util", "vram_used_mb", "vram_total_mb", "power_w", "temp_c", "sm_clock_mhz"]


def _smi(query, idx):
    if not shutil.which("nvidia-smi"):
        return None
    try:
        out = subprocess.check_output(
            ["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits", "-i", str(idx)],
            text=True, timeout=5).strip()
        return [x.strip() for x in out.split(",")]
    except Exception:
        return None


class GpuMonitor:
    def __init__(self, interval=0.5, gpu_index=0, server_names=(), out_csv=None):
        self.interval, self.idx = interval, gpu_index
        self.server_names = [s.strip().lower() for s in server_names if s.strip()]
        self.out_csv, self.samples = out_csv, []
        self._stop, self._thr, self._handle, self._procs = threading.Event(), None, None, []
        if pynvml:
            try:
                pynvml.nvmlInit()
                self._handle = pynvml.nvmlDeviceGetHandleByIndex(gpu_index)
            except Exception:
                self._handle = None

    def _server_rss(self, refresh):
        if not self.server_names:
            return None
        if refresh:
            self._procs = []
            for p in psutil.process_iter(["name"]):
                n = (p.info["name"] or "").lower()
                if any(s in n for s in self.server_names):
                    self._procs.append(p)
        total = 0
        for p in self._procs:
            try:
                total += p.memory_info().rss
            except Exception:
                pass
        return round(total / 2**20, 1) if self._procs else None

    def _gpu(self):
        d = dict.fromkeys(GPU_KEYS)
        h = self._handle
        if h is not None:
            try:
                u = pynvml.nvmlDeviceGetUtilizationRates(h)
                m = pynvml.nvmlDeviceGetMemoryInfo(h)
                d.update(gpu_util=u.gpu, mem_ctrl_util=u.memory,
                         vram_used_mb=round(m.used / 2**20), vram_total_mb=round(m.total / 2**20),
                         power_w=round(pynvml.nvmlDeviceGetPowerUsage(h) / 1000, 1),
                         temp_c=pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU),
                         sm_clock_mhz=pynvml.nvmlDeviceGetClockInfo(h, pynvml.NVML_CLOCK_SM))
                return d
            except Exception:
                pass
        r = _smi("utilization.gpu,utilization.memory,memory.used,memory.total,power.draw,"
                 "temperature.gpu,clocks.sm", self.idx)
        if r and len(r) == 7:
            try:
                for k, v in zip(GPU_KEYS, r):
                    d[k] = float(v)
            except ValueError:
                pass
        return d

    def _loop(self):
        psutil.cpu_percent(None)
        i = 0
        while not self._stop.is_set():
            t0 = time.time()
            row = {"t": round(t0, 3)}
            row.update(self._gpu())
            row["cpu_pct"] = psutil.cpu_percent(None)
            row["ram_used_mb"] = round(psutil.virtual_memory().used / 2**20)
            row["server_rss_mb"] = self._server_rss(i % 10 == 0)
            self.samples.append(row)
            i += 1
            self._stop.wait(max(0, self.interval - (time.time() - t0)))

    def start(self):
        self._thr = threading.Thread(target=self._loop, daemon=True)
        self._thr.start()

    def stop(self):
        self._stop.set()
        if self._thr:
            self._thr.join(timeout=5)
        if self.out_csv:
            with open(self.out_csv, "w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=FIELDS)
                w.writeheader()
                w.writerows(self.samples)
        return self.samples


def collect_env():
    env = {"platform": platform.platform(), "python": sys.version.split()[0],
           "cpu_logical_cores": psutil.cpu_count(),
           "ram_total_gb": round(psutil.virtual_memory().total / 2**30, 1)}
    try:
        with open("/proc/cpuinfo") as f:
            env["cpu_model"] = next(l.split(":")[1].strip() for l in f if l.startswith("model name"))
    except Exception:
        env["cpu_model"] = platform.processor()
    r = _smi("name,driver_version,memory.total,power.limit", 0)
    if r and len(r) == 4:
        env.update(gpu_name=r[0], driver=r[1], gpu_vram_mb=r[2], gpu_power_limit_w=r[3])
    else:
        env["gpu_name"] = None
    return env


if __name__ == "__main__":  # standalone: python monitor.py out.csv 60
    out = sys.argv[1] if len(sys.argv) > 1 else "telemetry.csv"
    secs = float(sys.argv[2]) if len(sys.argv) > 2 else 30
    m = GpuMonitor(out_csv=out); m.start(); time.sleep(secs); m.stop(); print("wrote", out)
