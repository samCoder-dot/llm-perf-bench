#!/usr/bin/env python3
"""Turn results/<label>/ folders into report/results.md, summary.csv/json and PNG graphs."""
import argparse, json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def load(d):
    d = Path(d)
    return dict(label=d.name, req=pd.read_csv(d / "requests.csv"), rounds=pd.read_csv(d / "rounds.csv"),
                tel=pd.read_csv(d / "telemetry.csv"), ph=pd.read_csv(d / "phases.csv"),
                env=json.loads((d / "env.json").read_text()))


def summarise(r):
    rows = []
    req, tel = r["req"], r["tel"]
    for _, p in r["ph"][r["ph"].name == "bench"].iterrows():
        size, conc = int(p.prompt_nominal), int(p.concurrency)
        q = req[(req.prompt_nominal == size) & (req.concurrency == conc)]
        ok = q[q.ok == True]
        rd = r["rounds"][(r["rounds"].prompt_nominal == size) & (r["rounds"].concurrency == conc)]
        t = tel[(tel.t >= p.start) & (tel.t <= p.end)]
        rows.append({
            "model_run": r["label"], "prompt_tokens(nominal)": size, "concurrency": conc,
            "requests_ok": f"{len(ok)}/{len(q)}",
            "prompt_tokens(actual)": ok.prompt_tokens.median(),
            "ttft_p50_s": ok.ttft_s.median(), "ttft_p95_s": ok.ttft_s.quantile(.95),
            "decode_tps_per_req_p50": ok.decode_tps.median(),
            "aggregate_tps_mean": rd.agg_tps.mean(), "aggregate_tps_std": rd.agg_tps.std(),
            "e2e_latency_p50_s": ok.e2e_s.median(), "e2e_latency_p95_s": ok.e2e_s.quantile(.95),
            "gpu_util_mean_pct": t.gpu_util.mean(), "gpu_util_max_pct": t.gpu_util.max(),
            "vram_peak_mb": t.vram_used_mb.max(), "power_mean_w": t.power_w.mean(),
            "temp_max_c": t.temp_c.max(), "cpu_mean_pct": t.cpu_pct.mean(),
            "server_rss_peak_mb": t.server_rss_mb.max(), "sys_ram_peak_mb": t.ram_used_mb.max()})
    return pd.DataFrame(rows)


def md_table(df, digits=2):
    def f(v):
        if isinstance(v, float):
            return "n/a" if np.isnan(v) else f"{v:.{digits}f}"
        return str(v)
    h = "| " + " | ".join(df.columns) + " |\n|" + "|".join("---" for _ in df.columns) + "|\n"
    return h + "\n".join("| " + " | ".join(f(v) for v in row) + " |" for row in df.itertuples(index=False)) + "\n"


def baseline(r):
    idle = r["ph"][r["ph"].name == "idle"].iloc[0]
    t = r["tel"][(r["tel"].t >= idle.start) & (r["tel"].t <= idle.end)]
    return t


def plot_throughput(runs, out):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for r in runs:
        for size, g in r["rounds"].groupby("prompt_nominal"):
            m = g.groupby("concurrency").agg_tps.agg(["mean", "std"]).fillna(0)
            axes[0].errorbar(m.index, m["mean"], yerr=m["std"], marker="o", capsize=3,
                             label=f"{r['label']} | ~{size} tok prompt")
        q = r["req"][r["req"].ok == True]
        for size, g in q.groupby("prompt_nominal"):
            m = g.groupby("concurrency").decode_tps.median()
            axes[1].plot(m.index, m.values, marker="s", label=f"{r['label']} | ~{size}")
    axes[0].set(title="Aggregate generation throughput", xlabel="Concurrent requests", ylabel="tokens / s (all streams)")
    axes[1].set(title="Per-request decode speed (median)", xlabel="Concurrent requests", ylabel="tokens / s per stream")
    for a in axes:
        a.grid(alpha=.3); a.set_xscale("log", base=2); a.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(out / "throughput_vs_concurrency.png", dpi=150); plt.close(fig)


def plot_ttft(runs, out):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for r in runs:
        q = r["req"][(r["req"].ok == True) & (r["req"].concurrency == r["req"].concurrency.min())]
        m = q.groupby("prompt_nominal").ttft_s.agg(["median", lambda s: s.quantile(.95)])
        m.columns = ["p50", "p95"]
        ax.plot(m.index, m.p50, marker="o", label=f"{r['label']} p50")
        ax.plot(m.index, m.p95, marker="x", ls="--", label=f"{r['label']} p95")
    ax.set(title="Time to first token vs prompt length (lowest concurrency)",
           xlabel="Prompt length (nominal tokens)", ylabel="seconds")
    ax.grid(alpha=.3); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(out / "ttft_vs_prompt_length.png", dpi=150); plt.close(fig)


def plot_memory(runs, out):
    labels, idle, peak, rss = [], [], [], []
    for r in runs:
        b = baseline(r)
        labels.append(r["label"])
        idle.append(b.vram_used_mb.median()); peak.append(r["tel"].vram_used_mb.max())
        rss.append(r["tel"].server_rss_mb.max())
    x, w = np.arange(len(labels)), 0.27
    fig, ax = plt.subplots(figsize=(max(6, 2.5 * len(labels)), 4.5))
    ax.bar(x - w, np.nan_to_num(idle), w, label="VRAM idle (model loaded)")
    ax.bar(x, np.nan_to_num(peak), w, label="VRAM peak under load")
    ax.bar(x + w, np.nan_to_num(rss), w, label="Server process RAM peak")
    ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=8); ax.set_ylabel("MB")
    ax.set_title("Memory footprint"); ax.legend(fontsize=8); ax.grid(axis="y", alpha=.3)
    fig.tight_layout(); fig.savefig(out / "memory_footprint.png", dpi=150); plt.close(fig)


def plot_timeline(r, out):
    tel, ph = r["tel"].copy(), r["ph"]
    t0 = tel.t.min(); tel["s"] = tel.t - t0
    panels = [("GPU utilisation (%)", ["gpu_util", "mem_ctrl_util"]), ("VRAM used (MB)", ["vram_used_mb"]),
              ("Power (W) / Temp (°C)", ["power_w", "temp_c"]), ("CPU % / server RSS (MB, right)", ["cpu_pct"])]
    fig, axes = plt.subplots(len(panels), 1, figsize=(13, 10), sharex=True)
    for ax, (title, cols) in zip(axes, panels):
        for c in cols:
            if tel[c].notna().any():
                ax.plot(tel.s, tel[c], label=c, lw=1)
        if title.startswith("CPU") and tel.server_rss_mb.notna().any():
            ax2 = ax.twinx(); ax2.plot(tel.s, tel.server_rss_mb, color="tab:red", lw=1, label="server_rss_mb")
            ax2.set_ylabel("MB")
        for i, (_, p) in enumerate(ph[ph.name == "bench"].iterrows()):
            ax.axvspan(p.start - t0, p.end - t0, alpha=.08 if i % 2 else .16, color="tab:blue")
            if ax is axes[0]:
                ax.text((p.start - t0 + p.end - t0) / 2, 101, f"c{int(p.concurrency)}/p{int(p.prompt_nominal)}",
                        rotation=90, fontsize=6, ha="center", va="bottom")
        ax.set_title(title, fontsize=9, loc="left"); ax.grid(alpha=.3)
        if ax.get_legend_handles_labels()[0]:
            ax.legend(fontsize=7, loc="upper right")
        else:
            ax.text(.5, .5, "no GPU telemetry available", transform=ax.transAxes, ha="center")
    axes[-1].set_xlabel("seconds since start (shaded = benchmark phase; c=concurrency, p=prompt tokens)")
    fig.suptitle(f"Real-time load: {r['label']}  ({r['env'].get('gpu_name')})", y=.995)
    fig.tight_layout(); fig.savefig(out / f"timeline_{r['label']}.png", dpi=140); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+", help="results/<label> folders")
    ap.add_argument("--out", default="report")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(exist_ok=True, parents=True)
    runs = [load(d) for d in a.runs]
    summ = pd.concat([summarise(r) for r in runs], ignore_index=True)
    summ.round(3).to_csv(out / "summary.csv", index=False)
    summ.round(3).to_json(out / "summary.json", orient="records", indent=2)
    plot_throughput(runs, out); plot_ttft(runs, out); plot_memory(runs, out)
    for r in runs:
        plot_timeline(r, out)

    md = ["# Benchmark results\n"]
    for r in runs:
        e = r["env"]
        md.append(f"## {r['label']}\n\nModel `{e.get('model')}` · GPU **{e.get('gpu_name')}** "
                  f"({e.get('gpu_vram_mb')} MB, driver {e.get('driver')}) · CPU {e.get('cpu_model')} · "
                  f"RAM {e.get('ram_total_gb')} GB · max_tokens {e.get('max_tokens')} · started {e.get('started')}\n")
        s = summ[summ.model_run == r["label"]].drop(columns="model_run")
        md.append("### Speed\n\n" + md_table(s[["prompt_tokens(nominal)", "concurrency", "requests_ok", "prompt_tokens(actual)",
                  "ttft_p50_s", "ttft_p95_s", "decode_tps_per_req_p50", "aggregate_tps_mean", "aggregate_tps_std",
                  "e2e_latency_p50_s", "e2e_latency_p95_s"]]))
        md.append("### GPU & memory during each phase\n\n" + md_table(s[["prompt_tokens(nominal)", "concurrency",
                  "gpu_util_mean_pct", "gpu_util_max_pct", "vram_peak_mb", "power_mean_w", "temp_max_c",
                  "cpu_mean_pct", "server_rss_peak_mb", "sys_ram_peak_mb"]], 1))
        b = baseline(r)
        md.append(f"Idle baseline (model loaded): VRAM {b.vram_used_mb.median()} MB, GPU util {b.gpu_util.mean()}%\n")
        md.append(f"![timeline](timeline_{r['label']}.png)\n")
    md.append("## Charts\n\n![throughput](throughput_vs_concurrency.png)\n\n![ttft](ttft_vs_prompt_length.png)\n\n"
              "![memory](memory_footprint.png)\n")
    (out / "results.md").write_text("\n".join(md))
    print(f"Report written to {out}/ (results.md, summary.csv/json, PNGs)")


if __name__ == "__main__":
    main()
