#!/usr/bin/env bash
# Benchmark one or more models back-to-back, then build the report.
# Usage: bash scripts/run_all.sh "gemma3:12b=gemma-12b" "<other-tag>=other"
# Override endpoint: BASE_URL=http://host:8000/v1 bash scripts/run_all.sh ...   Extra flags: EXTRA_ARGS="--rounds 3"
set -euo pipefail
BASE_URL="${BASE_URL:-http://localhost:11434/v1}"
GPU_TAG="$(nvidia-smi --query-gpu=name --format=csv,noheader -i 0 | tr ' ' '-' | tr -cd '[:alnum:]-')"
PAIRS=("$@"); [ ${#PAIRS[@]} -eq 0 ] && PAIRS=("gemma3:12b=gemma-12b")
DIRS=()
for p in "${PAIRS[@]}"; do
  model="${p%%=*}"; label="${p##*=}-${GPU_TAG}"
  # reload model so VRAM baseline is clean (Ollama only; harmless elsewhere)
  curl -s "${BASE_URL%/v1}/api/generate" -d "{\"model\":\"$model\",\"keep_alive\":0}" >/dev/null 2>&1 || true
  curl -s "${BASE_URL%/v1}/api/generate" -d "{\"model\":\"$model\",\"prompt\":\"hi\",\"stream\":false}" >/dev/null 2>&1 || true
  python bench/run_benchmark.py --base-url "$BASE_URL" --model "$model" --label "$label" ${EXTRA_ARGS:-}
  DIRS+=("results/$label")
done
python bench/report.py "${DIRS[@]}" --out report
