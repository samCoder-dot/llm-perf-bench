#!/usr/bin/env bash
# Fresh RunPod (Ubuntu + NVIDIA drivers) -> Ollama + benchmark deps. Usage: bash scripts/runpod_setup.sh gemma3:12b
set -euo pipefail
MODEL="${1:-gemma3:12b}"
apt-get update -qq && apt-get install -y -qq curl python3-pip git zstd >/dev/null
command -v ollama >/dev/null || curl -fsSL https://ollama.com/install.sh | sh
(pgrep -x ollama >/dev/null) || (nohup ollama serve > /tmp/ollama.log 2>&1 &)
sleep 5
ollama pull "$MODEL"
pip install -q -r requirements.txt
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv
echo "Ready. Run: bash scripts/run_all.sh"
