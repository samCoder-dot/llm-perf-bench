# Benchmark results

## dryrun-mock

Model `mock` · GPU **None** (None MB, driver None) · CPU Intel(R) Xeon(R) Processor @ 2.10GHz · RAM 3.9 GB · max_tokens 64 · started 2026-10-09 22:05:59

### Speed

| prompt_tokens(nominal) | concurrency | requests_ok | prompt_tokens(actual) | ttft_p50_s | ttft_p95_s | decode_tps_per_req_p50 | aggregate_tps_mean | aggregate_tps_std | e2e_latency_p50_s | e2e_latency_p95_s |
|---|---|---|---|---|---|---|---|---|---|---|
| 128 | 1 | 3/3 | 148.00 | 0.09 | 0.09 | 116.41 | 102.69 | 2.56 | 0.63 | 0.63 |
| 512 | 1 | 3/3 | 533.00 | 0.16 | 0.16 | 121.95 | 94.35 | 0.29 | 0.68 | 0.68 |
| 128 | 2 | 6/6 | 148.00 | 0.09 | 0.09 | 90.64 | 162.24 | 0.09 | 0.79 | 0.79 |
| 512 | 2 | 6/6 | 533.00 | 0.16 | 0.16 | 89.87 | 148.02 | 0.60 | 0.87 | 0.87 |
| 128 | 4 | 12/12 | 148.00 | 0.10 | 0.10 | 60.19 | 223.11 | 0.07 | 1.15 | 1.15 |
| 512 | 4 | 12/12 | 533.00 | 0.17 | 0.17 | 58.52 | 205.31 | 4.32 | 1.25 | 1.27 |

### GPU & memory during each phase

| prompt_tokens(nominal) | concurrency | gpu_util_mean_pct | gpu_util_max_pct | vram_peak_mb | power_mean_w | temp_max_c | cpu_mean_pct | server_rss_peak_mb | sys_ram_peak_mb |
|---|---|---|---|---|---|---|---|---|---|
| 128 | 1 | n/a | n/a | n/a | n/a | n/a | 5.0 | n/a | 252 |
| 512 | 1 | n/a | n/a | n/a | n/a | n/a | 3.0 | n/a | 252 |
| 128 | 2 | n/a | n/a | n/a | n/a | n/a | 2.1 | n/a | 252 |
| 512 | 2 | n/a | n/a | n/a | n/a | n/a | 4.0 | n/a | 252 |
| 128 | 4 | n/a | n/a | n/a | n/a | n/a | 4.3 | n/a | 252 |
| 512 | 4 | n/a | n/a | n/a | n/a | n/a | 5.3 | n/a | 252 |

Idle baseline (model loaded): VRAM nan MB, GPU util nan%

![timeline](timeline_dryrun-mock.png)

## Charts

![throughput](throughput_vs_concurrency.png)

![ttft](ttft_vs_prompt_length.png)

![memory](memory_footprint.png)
